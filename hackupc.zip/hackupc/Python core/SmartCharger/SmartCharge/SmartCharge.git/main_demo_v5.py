from threading import Timer
import time
import scipy.io
import numpy as np
import scipy.spatial.distance
import time
import matplotlib.pyplot as plt
from operator import itemgetter
from itertools import groupby
import random
def consecutive(data, stepsize=1):
    return np.split(data, np.where(np.diff(data) != stepsize)[0]+1)
def timeout():
    global eix_temporal
    global serie
    global serie_ori
    global t_time
    global j
    print("Timeout executed!")
    if(eix_temporal[0]==1):
        print("CHARGER ON")
    if(eix_temporal[0]==-1):
        print("CHARGER OFF")

    eix_temporal = np.roll(eix_temporal,-1)
    eix_temporal[-1] = 0

    t_time = t_time+1
    serie = serie_ori[t_time:t_time+48]
    serie = serie.reshape((1,-1))[0]

    print(eix_temporal)
    print(serie)

    j = j+1
    print("Capturnig Plot!")

    plt.plot(time_axis, serie,'ro')
    plt.plot(time_axis, serie)

    indices_one = np.where(eix_temporal == 1)[0]
    indices_eno = np.where(eix_temporal == -1)[0]

    number_ones = np.count_nonzero(eix_temporal==1)
    number_enos = np.count_nonzero(eix_temporal==-1)
    print("Number ones: ",number_ones)
    print("Number enos: ",number_enos)
    i = 0
    off = 0
    if( number_enos>number_ones):
        plt.hlines(28000,time_axis[0],time_axis[indices_eno[0]],linewidth=3000, color='#d62728',alpha=0.5)
        print("Dibuixant linea de ", 0, " a ", time_axis[indices_eno[0]])
        off = 1

    for i in range(i,number_ones):
        plt.hlines(28000,time_axis[indices_one[i]],time_axis[indices_eno[i+off]],linewidth=3000, color='#d62728',alpha=0.5)
        print("Dibuixant linea de ", time_axis[indices_one[i]], " a ", time_axis[indices_eno[i]])
    plt.xlabel('hours')
    plt.ylabel('TPR')
    plt.title('ROC curves mean vectors')
    plt.grid(True)
    straux = "testmean" + str(j) +".png"
    plt.savefig(straux)
    plt.clf()

    t = Timer(1, timeout)
    t.start()

def timeout2():
    print("Timeout2 executed!")
    data_recived()
    t2 = Timer(random.randint(48, 60), timeout2)
    t2.start()


def data_recived():
    global serie
    global t_time
    global eix_temporal
    mode = random.randint(0, 1)
    mode = 1
    if(mode == 0):
        t_start  = random.randint(1, 24)
        t_end = t_start + random.randint(1, 24)
        params = [t_start, t_end,0]
        print("new task started! charging from ",t_start," to ",t_end)
    if(mode ==1):
        charge_time = random.randint(1,11)
        charge_time_limit = random.randint(1,24)
        params = [charge_time, charge_time_limit,1]
        print("new task started! charging for ",charge_time," before ",charge_time_limit)



    params = [13,19,1]
    print(params)
    print("new task started! charging for ",7," before ",11)


    if(params[2]) == 0:
        print("Time origin: now: ", t_time , " start: ", t_start, " end: ", t_end)
        if(t_start<t_time):
            t_start = t_start+24
        if(t_start>t_end):
            t_end=t_end+24
        print("Time processed: now: ", t_time , " start: ", t_start, " end: ", t_end)
        eix_temporal[t_start-t_time] = 1
        eix_temporal[t_end-t_time] = -1


    if(params[2]) == 1:
        charge_time = params[0]
        charge_time_limit = params[1]
        if(charge_time_limit<t_time):
            charge_time_limit = charge_time_limit+24
        if(charge_time_limit<t_time+charge_time):
            charge_time_limit = charge_time_limit
        charge_time_limit = charge_time_limit-t_time
        print("Charging before ", charge_time_limit, " hours")


        serie2 = serie[:charge_time_limit]
        print(serie2)
        charge_time_limit = charge_time_limit -t_time
        serie_sorted_indexes = np.argsort(serie2, axis=0)
        index_bons = serie_sorted_indexes[:charge_time]
        index_bons = np.sort(index_bons)
        ilist = index_bons.tolist()
        index_bons_grouped = consecutive(ilist)

        for aux in index_bons_grouped:
            eix_temporal[aux[0]] = 1
            eix_temporal[aux[-1]+1] = -1
    print(eix_temporal)


eix_temporal = np.zeros(48)
time_axis = np.arange(48)
t_time = time.gmtime().tm_hour +1
serie_ori = np.loadtxt("forecast.txt")
#serie_ori = np.log(serie_ori)
serie = serie_ori[t_time:t_time+48]
serie = serie_ori[t_time:t_time+48]
serie = serie.reshape((1,-1))[0]

j = 0
t = Timer(1, timeout)
t.start()
time.sleep(0.5)
t2 = Timer(1, timeout2)
t2.start()

time.sleep(100000)






