
#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#define TCP_SERVER_PORT 5005

void tcp_client_init(void);

#endif
