/*
 *	user_config.h
 *
 *  Alejandro Woodward
 *
 */

#ifndef USER_CONFIG_H_
#define USER_CONFIG_H_

#define MILLISECOND 1000
#define SECOND 1000*MILLISECOND

#define SSID "wifi_normal"
//#define SSID_PASSWORD "9f8ac98b70ee1c7718d2"
#define SSID_PASSWORD "password_normal"

#define STA_MODE 0x01
#define PIN 2

#define ON "on"
#define OFF "off"

#endif /* USER_CONFIG_H_ */
