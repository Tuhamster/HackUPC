#include "osapi.h"
#include "user_interface.h"
#include "pwm.h"
#include "uart.h"
#include "mem.h"
#include "espmissingincludes.h"
#include "ets_sys.h"
#include "gpio.h"
#include "os_type.h"
#include "tcp_client.h"

static os_timer_t tcp_connect_timer;

void wifi_connect(){
    char ssid[32] = SSID;
    char password[64] = SSID_PASSWORD;
    struct station_config stationConf;

    //Set station mode
    wifi_set_opmode(STA_MODE);

    //Set ap settings
    os_memcpy(&stationConf.ssid, ssid, 32);
    os_memcpy(&stationConf.password, password, 32);
    wifi_station_set_config(&stationConf);
}

void tcp_client_connect(){

    //os_printf("Probando de conectar con el server.\n");

    if(wifi_station_get_connect_status() == STATION_GOT_IP){
        
        // For checking the IP given by the DHCP server
        /*struct ip_info info;

        uint8_t if_index = 0x00;
        wifi_get_ip_info(if_index, &info);

        os_printf("%d", (uint32_t)info.ip.addr);
        */
        tcp_client_init();
    }
    else
        os_timer_arm(&tcp_connect_timer, 1000, false);
}

void main(){

    wifi_connect();

    os_timer_disarm(&tcp_connect_timer);
    os_timer_setfn(&tcp_connect_timer, (os_timer_func_t *)tcp_client_connect, (void *)NULL);
    os_timer_arm(&tcp_connect_timer, 1000, false);
}

void user_init() {
	//uart_init(115200, 115200);
    gpio_init();
    gpio_output_set(0, 0, (1 << PIN), 0);  // set the pin as an output

	system_init_done_cb(main);
}
