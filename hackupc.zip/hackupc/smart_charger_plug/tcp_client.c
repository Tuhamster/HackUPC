#include "osapi.h"
#include "user_interface.h"
#include "pwm.h"
#include "uart.h"
#include "mem.h"
#include "gpio.h"
#include "espmissingincludes.h"
#include "espconn.h"
#include "user_config.h"
#include "tcp_client.h"
#include "user_config.h"

LOCAL struct espconn masterconn;
ip_addr_t tcp_server_ip;
LOCAL os_timer_t dns_timer;

uint8 _hostname[128];


static void tcp_recvcb(void *arg, char *data, unsigned short length){

    struct espconn *pespconn = (struct espconn *) arg;

    //os_printf("%s", data);

    if(strcmp(data, ON) == 0){
        gpio_output_set((1 << PIN), 0, 0, 0);
        espconn_send(pespconn, "ON", strlen("OK"));
    }
    else if(strcmp(data, OFF) == 0){
        gpio_output_set(0, (1 << PIN), 0, 0);
        espconn_send(pespconn, "OK", strlen("OK"));
    }
    else
        espconn_send(pespconn, "KO", strlen("KO"));
}

static void tcpclient_connectcb(void *arg){

    struct espconn *pespconn = (struct espconn *)arg;

    //os_printf("tcp connection established\n");

    espconn_regist_recvcb(pespconn, tcp_recvcb);

    //espconn_send(pespconn, "on", strlen("on"));
    
    if(GPIO_REG_READ(GPIO_OUT_ADDRESS) & (1 << PIN)){
        espconn_send(pespconn, "on", strlen("on"));
        //s_printf("Sending on\n");
    }
    else{
        espconn_send(pespconn, "off", strlen("off"));
        //os_printf("Sending off\n");
    }    
    espconn_regist_recvcb(pespconn, tcp_recvcb);
    
}

LOCAL void ICACHE_FLASH_ATTR 
user_esp_platform_dns_found(const char *name, ip_addr_t *ipaddr, void *arg){
    struct espconn *pespconn = (struct espconn *)arg;

    os_printf("Ejecutando dns_found");

    if (ipaddr == NULL) {
        os_printf("user_dns_found NULL \r\n");
        return;
    }

    //dns got ip
    //os_printf("user_dns_found %d.%d.%d.%d \r\n",*((uint8 *)&ipaddr->addr), *((uint8 *)&ipaddr->addr + 1), *((uint8 *)&ipaddr->addr + 2), *((uint8 *)&ipaddr->addr + 3));

    if (tcp_server_ip.addr == 0 && ipaddr->addr != 0) {
        // dns succeed, create tcp connection
        os_timer_disarm(&dns_timer);
        tcp_server_ip.addr = ipaddr->addr;
        os_memcpy(pespconn->proto.tcp->remote_ip, &ipaddr->addr, 4); // remote ip of tcp server which get by dns


        masterconn.proto.tcp->remote_port = 5005;
        
        pespconn->proto.tcp->local_port = espconn_port(); //local port of ESP8266

        espconn_regist_connectcb(pespconn, tcpclient_connectcb); // register connect callback
        //espconn_regist_reconcb(pespconn, user_tcp_recon_cb); // register reconnect callback as error handler

        espconn_connect(pespconn);
    }
}

static user_dns_check_cb(void *arg)
{
    struct espconn *pespconn = arg;
    espconn_gethostbyname(pespconn, _hostname, &tcp_server_ip, user_esp_platform_dns_found); // recall DNS function
    os_timer_arm(&dns_timer, 1000, 0);
}

void tcp_client_init(void){

    //os_printf("Iniciando el cliente.\n");

    uint32_t ipAddr = ipaddr_addr("34.249.135.120");

    masterconn.proto.tcp = (esp_tcp *)os_zalloc(sizeof(esp_tcp));
    masterconn.type = ESPCONN_TCP;
    masterconn.state = ESPCONN_NONE;

    masterconn.proto.tcp->remote_port = 12345;
        
    masterconn.proto.tcp->local_port = espconn_port(); //local port of ESP8266
    os_memcpy(masterconn.proto.tcp->remote_ip, &ipAddr, 4);

    espconn_regist_connectcb(&masterconn, tcpclient_connectcb); // register connect callback
    //espconn_regist_reconcb(pespconn, user_tcp_recon_cb); // register reconnect callback as error handler

    espconn_connect(&masterconn);



    /*
    tcp_server_ip.addr = 0;
    espconn_gethostbyname(&masterconn, _hostname, &tcp_server_ip, user_esp_platform_dns_found); // DNS function

    os_timer_setfn(&dns_timer, (os_timer_func_t *)user_dns_check_cb, (void*)&masterconn);
    os_timer_arm(&dns_timer, 1000, 0);
    */

}